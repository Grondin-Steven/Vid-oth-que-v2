    <div class="wrapper col col-md bg-info">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="mt-5 mb-3">ERREUR 404</h2>
                    <div class="alert alert-danger">Désoler une erreur s'est produite sur la requête : <a href="dashboard.php" class="alert-link">retour au Dashboard</a></div>
                </div>
            </div>        
        </div>
    </div>